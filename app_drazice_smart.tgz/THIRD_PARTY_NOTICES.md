# Third-Party Notices / Повідомлення про сторонні компоненти

Цей проєкт **посилається** на сторонній код, але не включає його копій у
власний репозиторій, окрім випадків, явно зазначених нижче.

## 1. LubosD/esphome-smartboiler (BLE-компонент, вендоровано)

- Репозиторій: https://github.com/LubosD/esphome-smartboiler
- Автор: LubosD та контриб'ютори
- Зафіксований commit походження: `c1b4e18ded8d3de58a19022e5155134982ddeb9a`
- Розташування в цьому проєкті: `firmware/components/smartboiler/`
- Роль: реалізація BLE-протоколу Drazice SMART.

**Дозвіл.** Автор upstream (LubosD) **надав дозвіл** на використання свого коду
в цьому проєкті. Тому код **вендоровано** (включено безпосередньо) замість
підключення через `external_components: git`. Це робить збірку відтворюваною і
незалежною від доступності зовнішнього репозиторію під час компіляції.

Атрибуція поряд з кодом — `firmware/components/smartboiler/UPSTREAM.md`.
Виправлення цього коду бажано надсилати також в upstream. Якщо upstream додасть
окремий файл ліцензії — додайте його копію поряд і оновіть це повідомлення.

**Локальна модифікація (2025-01, ux-critique §5-E):** у нашому codegen
(`__init__.py`) знижено мінімум числа Pairing PIN з `1111` до `0`, щоб приймати
реальні 4-значні коди спарювання з провідними нулями (наприклад `0692`).
`send_pin` уже передає будь-яке значення через `write_le()`, тому
`smartboiler.cpp` не змінювався — зміна стосується лише нашого codegen, а не
upstream BLE-протоколу.

**Локальна модифікація (pairing-trace):** у `smartboiler.h`, `smartboiler.cpp`
і `__init__.py` додано діагностику парингу (кільцева траса подій, причина
розриву GATT, лічильники запитів PIN і перебудов лінка; нові entity
`Boiler Pair Trace`, `Boiler Last Disconnect`, `Boiler Pair Attempts`,
`Boiler Connect Count`) та редагування PIN у DEBUG-логу. BLE-протокол і логіка
спарювання не змінені. Деталі — `firmware/components/smartboiler/UPSTREAM.md`.

## 2. ESPHome

- https://esphome.io — ліцензії MIT (ядро) та GPLv3 (окремі частини).
- Використовується як інструмент збірки прошивки; не розповсюджується в складі
  цього репозиторію.

### 2a. ESPHome `web_server` — ВИДАЛЕНО (більше не вендоровано)

Вендорований компонент `web_server` (разом із його залежностями
`ESPAsyncWebServer`, `AsyncTCP`, `ArduinoJson`) **видалено** з репозиторію у
версії 1.5.0. Навіть із вимкненим SSE він вичерпував heap під Bluedroid BLE
(вільного heap лишалося ~208 байт → `Empty reply from server`). Каталог
`firmware/components/web_server/` **видалено повністю**; попередня атрибуція в
`UPSTREAM.md` знята разом із ним.

Заміна — власний компонент `firmware/components/rest_api/` (власний код цього
проєкту, без вендорингу). Він спирається лише на `WiFiServer`/`WiFiClient` з
ядра Arduino-ESP32 (бібліотека `WiFi`, вже присутня в ESPHome-збірці) і будує
JSON вручну. **Жодної нової сторонньої залежності** не додано — навпаки,
прибрано три (`ESPAsyncWebServer`, `AsyncTCP`, `ArduinoJson`).

## 3. MajorDoMo

- https://github.com/sergejey/majordomo
- Цільова платформа. Модуль `drazice_smart` — незалежний код під MIT, який
  працює поверх MajorDoMo через його публічні механізми модулів.

## 4. Залежності PHP-модуля

Модуль `drazice_smart` написаний без зовнішніх Composer-залежностей, сумісний з
PHP 7.3. Жодних vendored-бібліотек не включено.
