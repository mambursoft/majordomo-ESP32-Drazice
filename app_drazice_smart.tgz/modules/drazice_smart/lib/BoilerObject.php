<?php
/**
 * BoilerObject: the single MajorDoMo object that represents the boiler AND its
 * ESP32 as one entity (default title "EspBoiler", class "EspBoiler").
 *
 * Everything the ESP can read from the boiler, plus ESP diagnostics, plus the
 * toilet-presence sessions and the events to process, is stored as properties
 * of THIS one object.
 *
 * Property groups:
 *   - READ-ONLY telemetry/diagnostics (written by the module from the ESP);
 *   - CONTROL properties whose change is applied TO THE BOILER. These are
 *     clearly marked in their DESCRIPTION ("⚙ ЗМІНА ЦІЄЇ ВЛАСТИВОСТІ
 *     ЗАСТОСОВУЄТЬСЯ ДО БОЙЛЕРА ...") and get a linked method so a change made
 *     anywhere in MajorDoMo (UI, scene, rule, app) is picked up and routed
 *     through the guarded REST path (cooldown / lease preserved);
 *   - PRESENCE session/event properties.
 *
 * Object/property creation is idempotent and uses the MajorDoMo DB schema
 * directly (objects / classes / properties / methods / pvalues), because core
 * exposes addClassObject() but no high-level "add property with description +
 * linked method" helper. All writes guard function_exists() so unit tests
 * (which do not load this class) are unaffected.
 *
 * PHP 7.3 compatible.
 *
 * @package drazice_smart
 * @license MIT
 */

namespace DraziceSmart;

class BoilerObject
{
    const CLASS_NAME = 'EspBoiler';

    /**
     * Full property catalogue of the single boiler+ESP object.
     * key => array(desc, control(bool), method(string|null))
     * "control" properties are applied TO the boiler when changed.
     */
    public static function catalogue()
    {
        // history = number of days to keep (0 = off). $h defaults to 30 days,
        // $h3 keeps a short 3-day archive (operational, not long-term charts).
        $c = function ($desc) { return array('desc' => $desc, 'control' => false, 'method' => null, 'history' => 0); };
        $h = function ($desc, $days = 30) { return array('desc' => $desc, 'control' => false, 'method' => null, 'history' => (int) $days); };
        $h3 = function ($desc) { return array('desc' => $desc, 'control' => false, 'method' => null, 'history' => 3); };
        $w = function ($desc, $method) { return array('desc' => $desc, 'control' => true, 'method' => $method, 'history' => 0); };
        // $p: a read-only presence property with its OWN linked method, invoked
        // by MajorDoMo on every value change (properties.ONCHANGE = method).
        $p = function ($desc, $method) { return array('desc' => $desc, 'control' => false, 'method' => $method, 'history' => 0, 'onchange' => true); };

        $applied = '⚙ КЕРУВАННЯ: зміна цієї властивості ЗАСТОСОВУЄТЬСЯ ДО БОЙЛЕРА через ESP32 (з дотриманням cooldown/lease). ';

        $cat = array(
            // --- read-only telemetry from the boiler ---
            'tempUpper'      => $h3('Температура верхнього датчика бойлера, °C (лише читання, з ESP). Архів 3 дні.'),
            'tempLower'      => $h3('Температура нижнього датчика бойлера, °C (лише читання, з ESP). Архів 3 дні.'),
            'heating'        => $h('Чи гріє бойлер зараз (Heat), 1/0 (лише читання, з ESP). Історія увімкнена — видно моменти перемикання негріє/гріє.'),
            'hdo'            => $h3('Стан тарифного входу HDO, 1/0 (лише читання, з ESP). Архів 3 дні.'),
            'reportedMode'   => $c('Поточний режим бойлера, повідомлений бойлером (лише читання).'),
            'energyTotalKwh' => $h3('Накопичена енергія бойлера, кВт·год (лише читання, з ESP). Архів 3 дні.'),
            'boilerVersion'  => $c('Версія прошивки/серійний номер бойлера (лише читання).'),
            'boilerName'     => $c('Назва бойлера (лише читання).'),
            'bleState'       => $h3('Стан BLE-з\'єднання ESP↔бойлер (лише читання). Архів 3 дні.'),
            // --- ESP diagnostics ---
            'espUptime'      => $c('Час роботи ESP32, с (діагностика, лише читання).'),
            'espRssi'        => $c('Рівень Wi-Fi сигналу ESP32, dBm (діагностика).'),
            'espFreeHeap'    => $c('Вільна пам\'ять ESP32, байт (діагностика).'),
            'espResetReason' => $c('Причина останнього перезапуску ESP32 (діагностика).'),
            'guardState'     => $c('Стан локального захисту (guard) на ESP32 (діагностика).'),
            'guardReason'    => $c('Причина поточного стану guard (діагностика).'),
            'continuousHeatSeconds' => $c('Тривалість безперервного фактичного нагріву, с (діагностика).'),
            'cooldownRemaining'     => $c('Залишок обов\'язкової паузи (cooldown), с (діагностика).'),
            'leaseRemaining'        => $c('Залишок дозволу (lease), с (діагностика).'),
            // --- planner / policy (read-only reflections) ---
            'powerSource'    => $c('Джерело живлення: grid/battery/unknown (лише читання, трактування).'),
            'batterySoc'     => $c('Заряд батареї SOC, % (з прив\'язаної властивості, лише читання).'),
            'tariffActive'   => $c('Чи активний пільговий тариф зараз, 1/0 (лише читання).'),
            'reportedTarget' => $c('Фактична цільова температура бойлера, °C (лише читання).'),
            'plannedTarget'  => $c('Ціль, яку порахував планувальник, °C (лише читання).'),
            'controlState'   => $h3('Поточна дія планувальника: heat/hold (лише читання). Архів 3 дні — рішення модуля окремо від фактичного Heat бойлера.'),
            'decisionReason' => $h3('Коротка причина рішення планувальника (лише читання). Архів 3 дні.'),
            'decisionHuman'  => $h3('Пояснення «чому гріє / чому ні» людською мовою (лише читання). Архів 3 дні.'),
            'decisionAllowed'=> $c('Чи дозволено нагрів поточним рішенням, 1/0 (лише читання).'),
            'decisionLevel'  => $c('Рівень пріоритету спрацьованого правила (лише читання).'),
            'decisionLog'    => $h('Компактний рядок рішення. Історія увімкнена — видно рішення за останні дні.'),
            'batterySocHist' => $h('SOC батареї з історією (окрема копія для графіка).'),
            'hdoDesired'     => $c('Бажаний стан HDO, порахований модулем, 1/0 (лише читання).'),
            'hdoControlEnabled' => $c('Чи ввімкнено керування HDO (сонячний оверрайд), 1/0 (лише читання).'),
            'vacationActive' => $c('Чи активний режим відпустки зараз, 1/0 (лише читання).'),
            'connected'      => $h3('Чи доступний ESP32 по HTTP, 1/0 (лише читання). Архів 3 дні.'),
            'lastSampleUtc'  => $c('UTC час останнього зчитування телеметрії (лише читання).'),
            // --- boiler internal clock vs server clock (drift check) ---
            'boilerClock'           => $c('Внутрішній годинник бойлера (день тижня + час доби, напр. "Mon 14:03:27"), прочитаний по BLE (лише читання).'),
            'boilerClockSkewSeconds'=> $h3('Відхилення годинника бойлера від сервера, с (+ бойлер поспішає). Архів 3 дні.'),
            'boilerClockOk'         => $c('Чи в межах порога відхилення годинника, 1/0 (лише читання).'),

            // --- CONTROL properties (change -> applied to the boiler) ---
            'requestedTarget'   => $w($applied . 'Запит цільової температури, °C (40..80).', 'applyRequestedTarget'),
            'requestedMode'     => $w($applied . 'Запит режиму: ANTIFREEZE/SMART/PROG/MANUAL.', 'applyRequestedMode'),
            'boost'             => $w($applied . 'Разовий boost: встав 1, щоб запустити нагрів на BOOST_TTL; 0 — скасувати.', 'applyBoost'),
            'automationEnabled' => $w($applied . 'Увімкнути (1) / вимкнути (0) автоматичне керування бойлером.', 'applyAutomationEnabled'),
            'allowBatteryHeat'  => $w($applied . 'Дозволити (1) нагрів навіть від акумуляторів (безпека бойлера зберігається).', 'applyAllowBatteryHeat'),

            // --- toilet presence sessions & events (written by the module) ---
            // Each presence property gets its OWN linked method (ONCHANGE) on
            // the object, so a change fires EspBoiler.<method>() which the user
            // can extend. Default body routes to the module's presence handler.
            'presentPeople'      => $p('Хто зараз присутній у туалеті і як довго (людський опис, лише читання).', 'onPresentPeopleChange'),
            'presenceSessionJson'=> $p('Активні сесії присутності (JSON): person, since_utc, duration_s, source (ble/wifi).', 'onPresenceSessionChange'),
            'presenceEvent'      => $p('Остання подія присутності для обробки: entered/long/too_long/left + person.', 'onPresenceEventChange'),
            'presenceEventJson'  => $p('Повна остання подія присутності (JSON) для обробника/сцен.', 'onPresenceEventJsonChange'),
        );

        // User hooks: telemetry/decision properties get an EMPTY class method
        // "on<Name>Change" linked via ONCHANGE, for the owner's own logic. The
        // module creates the stub ONCE and never overwrites its code afterwards.
        foreach (self::userHookProperties() as $name) {
            if (isset($cat[$name]) && empty($cat[$name]['method'])) {
                $cat[$name]['method'] = self::userMethodName($name);
                $cat[$name]['onchange'] = true;
                $cat[$name]['user'] = true;
            }
        }
        return $cat;
    }

    /** Properties that get an owner-editable ONCHANGE hook. */
    public static function userHookProperties()
    {
        return array(
            'tempUpper', 'tempLower', 'heating', 'hdo', 'reportedMode', 'energyTotalKwh',
            'bleState', 'plannedTarget', 'controlState',
            'decisionReason', 'decisionHuman', 'batterySocHist',
            'connected', 'boilerClockSkewSeconds', 'guardState', 'guardReason',
        );
    }

    /** Hook method name for a property: tempUpper -> onTempUpperChange. */
    public static function userMethodName($property)
    {
        return 'on' . ucfirst($property) . 'Change';
    }

    public static function available()
    {
        return function_exists('SQLSelectOne') && function_exists('addClassObject')
            && function_exists('setGlobal');
    }

    /**
     * Create the object + all properties (with DESCRIPTION) and attach linked
     * methods to control properties. Idempotent. $objectTitle lets the admin
     * rename the object; defaults to the class name.
     */
    public static function ensureObject($objectTitle, $moduleName)
    {
        if (!self::available()) {
            return array('ok' => false, 'reason' => 'objects_runtime_unavailable');
        }
        $objectTitle = ($objectTitle !== '') ? $objectTitle : self::CLASS_NAME;

        // 1. Object (idempotent by title; addClassObject also creates the class).
        $objectId = addClassObject(self::CLASS_NAME, $objectTitle, 'drazice_' . $moduleName);
        if (!$objectId) {
            return array('ok' => false, 'reason' => 'object_create_failed');
        }

        // 2. Properties with descriptions; handler methods + ONCHANGE links.
        $objRow = SQLSelectOne("SELECT CLASS_ID FROM objects WHERE ID=" . (int) $objectId);
        $classId = (is_array($objRow) && isset($objRow['CLASS_ID'])) ? (int) $objRow['CLASS_ID'] : 0;
        $created = 0;
        $linked = 0;
        foreach (self::catalogue() as $name => $def) {
            $histDays = isset($def['history']) ? (int) $def['history'] : 0;
            self::ensureProperty($objectId, $classId, $name, $def['desc'], $histDays);
            if (!empty($def['method']) && (!empty($def['control']) || !empty($def['onchange']))) {
                $kind = !empty($def['control']) ? 'control' : (!empty($def['user']) ? 'user' : 'presence');
                if (self::ensureHandlerMethod($objectId, $classId, $name, $def['method'], $kind, $moduleName)) {
                    $linked++;
                }
            }
            $created++;
        }
        return array('ok' => true, 'object' => $objectTitle, 'properties' => $created, 'linked' => $linked);
    }

    /**
     * Create one property (with DESCRIPTION) on the object if missing.
     * $histDays is the MajorDoMo KEEP_HISTORY retention in DAYS (0 = off).
     * The catalogue value is AUTHORITATIVE for the properties the module owns:
     * on an existing property we set it exactly (both raising and shortening),
     * so a deliberate short archive like 3 days is applied even if an older
     * build left 30. History is only disabled where the catalogue asks for 0.
     */
    private static function ensureProperty($objectId, $classId, $name, $description, $histDays = 0)
    {
        $histDays = (int) $histDays;
        $classId = (int) $classId;
        $title = self::safe($name);

        // Properties live on the CLASS (CLASS_ID=class, OBJECT_ID=0): the object
        // inherits them, and a class-level ONCHANGE is visible in the UI.
        $rec = $classId > 0
            ? SQLSelectOne("SELECT ID FROM properties WHERE CLASS_ID=" . $classId . " AND OBJECT_ID=0 AND TITLE='" . $title . "'")
            : null;
        $legacy = SQLSelectOne("SELECT ID FROM properties WHERE OBJECT_ID=" . (int) $objectId . " AND TITLE='" . $title . "'");
        $hasLegacy = is_array($legacy) && !empty($legacy['ID']);
        $hasClass = is_array($rec) && !empty($rec['ID']);

        if ($classId > 0 && $hasLegacy && !$hasClass) {
            // Migrate in place: same property ID, so pvalues (current value) and
            // history rows stay attached. Only the owner changes.
            SQLExec("UPDATE properties SET CLASS_ID=" . $classId . ", OBJECT_ID=0 WHERE ID=" . (int) $legacy['ID']);
            $rec = array('ID' => $legacy['ID']);
            $hasClass = true;
        } elseif ($classId > 0 && $hasLegacy && $hasClass) {
            // Both exist: re-point values to the class property, drop the copy.
            SQLExec("UPDATE pvalues SET PROPERTY_ID=" . (int) $rec['ID'] . " WHERE PROPERTY_ID=" . (int) $legacy['ID']);
            SQLExec("DELETE FROM properties WHERE ID=" . (int) $legacy['ID']);
        } elseif ($classId <= 0 && $hasLegacy) {
            $rec = $legacy;
            $hasClass = true;
        }

        if ($hasClass) {
            $upd = SQLSelectOne("SELECT ID, DESCRIPTION, KEEP_HISTORY FROM properties WHERE ID=" . (int) $rec['ID']);
            $changed = false;
            if (is_array($upd)) {
                if (isset($upd['DESCRIPTION']) && $upd['DESCRIPTION'] !== $description) {
                    $upd['DESCRIPTION'] = $description;
                    $changed = true;
                }
                $cur = (int) (isset($upd['KEEP_HISTORY']) ? $upd['KEEP_HISTORY'] : 0);
                // The catalogue retention is authoritative for the properties
                // the module manages: apply it exactly when it differs (both up
                // and down), so a deliberate short archive (e.g. 3 days) is set
                // even if an older build had left 30. History stays OFF only
                // where the catalogue itself asks for 0.
                if ($histDays > 0 && $cur !== $histDays) {
                    $upd['KEEP_HISTORY'] = $histDays;
                    $changed = true;
                }
                if ($changed) {
                    SQLUpdate('properties', $upd);
                }
            }
            return (int) $rec['ID'];
        }
        $prop = array(
            'OBJECT_ID'   => $classId > 0 ? 0 : (int) $objectId,
            'CLASS_ID'    => $classId,
            'TITLE'       => $name,
            'DESCRIPTION' => $description,
            'KEEP_HISTORY'=> $histDays,
        );
        return (int) SQLInsert('properties', $prop);
    }

    /**
     * PHP source of an auto-generated handler method. Pure (no DB), so a unit
     * test can check it. The code runs inside MajorDoMo's callMethod() eval, so
     * $this is the boiler object (works for a CLASS-level method too) and
     * $params carries PROPERTY / NEW_VALUE / OLD_VALUE / SOURCE from setProperty().
     *
     * @param string $kind     'control' (change is applied to the boiler) or
     *                         'presence' (change is routed to onPresenceChange)
     * @param string $property property name on the object
     */
    public static function handlerCode($kind, $property, $moduleName)
    {
        $new = "(isset(\$params['NEW_VALUE']) ? \$params['NEW_VALUE'] : getGlobal(\$this->object_title . '." . $property . "'))";
        $old = "(isset(\$params['OLD_VALUE']) ? \$params['OLD_VALUE'] : '')";
        if ($kind === 'control') {
            $head = "// AUTO: a change of '" . $property . "' is applied to the boiler (guarded REST).\n";
            $call = "\$m->applyObjectControl('" . $property . "', " . $new . ");";
        } elseif ($kind === 'user') {
            // Owner-editable stub: no module call, no writes (so no feedback loop).
            return "// USER HOOK: runs on every change of '" . $property . "'.\n"
                . "// Write your own logic here. The module creates this method once and\n"
                . "// NEVER overwrites its code afterwards.\n"
                . "// \$params['NEW_VALUE'], \$params['OLD_VALUE'], \$this->object_title\n"
                . "// Example: \$v = \$params['NEW_VALUE'];\n";
        } else {
            $head = "// AUTO: fired on every change of '" . $property . "' (presence). Extend onPresenceChange().\n";
            $call = "\$m->onPresenceChange('" . $property . "', " . $new . ", " . $old . ");";
        }
        return $head
            . "if (!class_exists('drazice_smart')) {\n"
            . "    @include_once(DIR_MODULES.'" . $moduleName . "/" . $moduleName . ".class.php');\n"
            . "}\n"
            . "if (class_exists('drazice_smart')) {\n"
            . "    \$m = new drazice_smart();\n"
            . "    " . $call . "\n"
            . "}\n";
    }

    /**
     * Create/refresh the handler method for a property and link it to the
     * property (properties.ONCHANGE). Idempotent.
     *
     * The method lives on the CLASS (CLASS_ID = object's class, OBJECT_ID = 0),
     * not on the single object, because the MajorDoMo object editor builds the
     * "run method on change" list from CLASS methods only. A method that exists
     * only on the object still runs, but is invisible in the UI, and saving the
     * property in the UI would then blank ONCHANGE. Any older object-level copy
     * created by this module (DESCRIPTION starts with "AUTO:") is removed so it
     * cannot shadow the class method.
     *
     * @return bool true when the method exists and the property is linked
     */
    private static function ensureHandlerMethod($objectId, $classId, $property, $methodName, $kind, $moduleName)
    {
        if ($classId <= 0) {
            return false;
        }
        $code = self::handlerCode($kind, $property, $moduleName);
        if ($kind === 'control') {
            $desc = 'AUTO: застосовує зміну властивості ' . $property . ' до бойлера (guarded).';
        } elseif ($kind === 'user') {
            $desc = 'USER: ваш обробник зміни ' . $property . ' (модуль не перезаписує код).';
        } else {
            $desc = 'AUTO: обробник зміни властивості ' . $property . ' (присутність).';
        }

        $exists = SQLSelectOne("SELECT ID FROM methods WHERE CLASS_ID=" . (int) $classId
            . " AND OBJECT_ID=0 AND TITLE='" . self::safe($methodName) . "'");
        if (is_array($exists) && !empty($exists['ID'])) {
            // A user hook is owned by the user: never touch its code/description.
            if ($kind !== 'user') {
                $rec = SQLSelectOne("SELECT * FROM methods WHERE ID=" . (int) $exists['ID']);
                $rec['CODE'] = $code;
                $rec['DESCRIPTION'] = $desc;
                SQLUpdate('methods', $rec);
            }
        } else {
            $rec = array(
                'CLASS_ID'    => (int) $classId,
                'OBJECT_ID'   => 0,
                'TITLE'       => $methodName,
                'DESCRIPTION' => $desc,
                'CODE'        => $code,
            );
            SQLInsert('methods', $rec);
        }

        // Drop our own stale object-level copy (it would override the class method).
        if (function_exists('SQLExec')) {
            SQLExec("DELETE FROM methods WHERE OBJECT_ID=" . (int) $objectId
                . " AND TITLE='" . self::safe($methodName) . "' AND DESCRIPTION LIKE 'AUTO:%'");
        }

        return self::setOnChange($objectId, $classId, $property, $methodName) > 0;
    }

    /** Set properties.ONCHANGE = method for a given property (idempotent). */
    private static function setOnChange($objectId, $classId, $property, $methodName)
    {
        // Class-level property first (current layout), object-level as fallback.
        $rec = SQLSelectOne("SELECT ID, ONCHANGE FROM properties WHERE OBJECT_ID=0 AND CLASS_ID=" . (int) $classId
            . " AND TITLE='" . self::safe($property) . "'");
        if (!is_array($rec) || empty($rec['ID'])) {
            $rec = SQLSelectOne("SELECT ID, ONCHANGE FROM properties WHERE OBJECT_ID=" . (int) $objectId
                . " AND TITLE='" . self::safe($property) . "'");
        }
        if (is_array($rec) && !empty($rec['ID'])) {
            if (!isset($rec['ONCHANGE']) || $rec['ONCHANGE'] !== $methodName) {
                $rec['ONCHANGE'] = $methodName;
                SQLUpdate('properties', $rec);
            }
            return (int) $rec['ID'];
        }
        return 0;
    }

    /** Dirty-check write of a single property (avoids setGlobal feedback loops). */
    public static function set($objectTitle, $prop, $val)
    {
        if (!function_exists('setGlobal') || !function_exists('getGlobal')) {
            return;
        }
        if ($val === null) {
            return;
        }
        $full = $objectTitle . '.' . $prop;
        $cur = getGlobal($full);
        if ((string) $cur !== (string) $val) {
            setGlobal($full, $val);
        }
    }

    private static function safe($s)
    {
        return function_exists('DBSafe') ? DBSafe($s) : addslashes($s);
    }
}
